/*
Contoh program penggunaan RTOS.


Device	: ATmega32
Clock 	: 12 MHz
Koneksi	: - PORTA 		<-> LCD_DATA
		  - PORTC 5,6,7 <-> LCD_CONTROL
		  - PORTC 0,1	<-> I2C BUS
		  - PORTB 3		<-> Speaker
		  - PORTD		<-> LED

Library	: 	AVR-Libc
			FreeRTOS
			I2C Library

Notes	: 

Tim Asisten Sistem Tertanam 2011
(M. Sakti Alvissalim, Faris Al Afif, Big Zaman)
@ver: ESAT 2013
*/

#include <stdlib.h>
#include <avr/pgmspace.h>
#include "FreeRTOS.h"
#include "task.h"
#include "i2c.h"
#include "lcd.h"
#include "sample.c"
#include "util/delay.h"
#define TICKS_PER_MS 5

unsigned char notes[] = {
0,90,80,71,67,60,53,47,45,40,36,34,30,27,24,22,20,18,17,15,13,12,11};

unsigned int song1[] = {
1,2,3,4,5,3,1,1,1,
6,8,7,6,5,5,5,
4,6,5,4,3,1,1,1,
2,4,3,2,1,1,1};

unsigned int song2[] = {
3, 6, 7, 8, 6, 7, 8, 7, 5, 5, 5,
3, 4, 4, 5, 6, 5, 4, 3, 3, 3,
3, 2, 2, 2, 2, 6, 4, 3, 4, 3, 2, 1, 1, 1,
3, 6, 6, 6, 6, 7, 8, 7, 7, 7, 7, 7,
3, 6, 7, 8, 6, 7, 8, 7, 5, 5, 5,
3, 4, 4, 5, 6, 5, 4, 3, 3, 3,
3, 2, 2, 2, 2, 6, 4, 3, 4, 3, 2, 1, 1, 1,
3, 6, 7, 8, 7, 8, 7, 6, 6, 6, 6, 6, 6, 6, 6};

/** 	
This task measures distance using the SRF08 every 100 ms 
and display the result in cm to LCD
*/
int global_sonar_cm = 0;
void vSonarTask( void * pvParameters )
{
    char lcd[16];
	int i = 0;
	init_lcd();
	
	while(1){
		unsigned int data = 0;
		// Send command to start measurement
 		i2c_transmit(0xE0, 0, 81);
		// Wait for the measurement to be done
		vTaskDelay(70 * TICKS_PER_MS);
		// Read the 16 bit result
		data = i2cRead(0xE0, 2) << 8;
		data |= i2cRead(0xE0, 3);
		global_sonar_cm = data;
		// Convert the data to string
		ltoa(data, lcd, 10);

		// Clear the LCD
		init_lcd();
		
		// Display the distance to LCD
		for(i=0; i<16; i++){
			if(lcd[i]==0){
				break;
			}
			//tulis_data_ram_lcd('E');

			tulis_data_ram_lcd(lcd[i]);
		}
		
		// Delay for another 100 ms
		vTaskDelay(100 * TICKS_PER_MS);
	}
}

/** 	
This task plays a series of musical notes in order to produce a "song"
*/
void vMusicTask( void * pvParameters ){
	int i;
	DDRB = 0xFF;

	/** 
	Timer/Counter 0
	Clock value = 11.719 KHz
	Mode = CTC top=OCR0
	OC0 output: Toggle on compare match
	*/
	TCCR0=0x1D;
	TCNT0=0x00;
	OCR0=0x00;

	while(1){
		for(i=0; i<31; i++){
			// Set the new desired frequency
			OCR0 = notes[song1[i]+8];

			// Delay for half a second
			vTaskDelay(500 * TICKS_PER_MS);
		}
	}
}

/** 	
This task plays sound previously recorded from PC
*/
void vSoundTask( void * pvParameters ){
	int i;
	DDRB = 0xFF;

	portTickType xLastWakeTime;
	
	/** 
	Timer/Counter 0
	Clock value = 12 MHz
	Mode = Fast PWM
	OC0 output: Non-Inverted PWM
	*/
	TCCR0=0x69;
	TCNT0=0x00;
	OCR0=0x00;
	
	while(1){
		// Need to current tick for precise timing
		xLastWakeTime = xTaskGetTickCount();

		for(i=0; i< sample_length; i+=10){
			// Make sure the OCR assignment is uninterrupted by other task
			taskENTER_CRITICAL();
			OCR0 = pgm_read_byte(&sample_data[i]);
			// Allow other task to interrupt
			taskEXIT_CRITICAL();
			// Delay for 1 ms
			vTaskDelay( 1 * TICKS_PER_MS );
		}
		// Delay 1s before another playback
		vTaskDelay(1000 * TICKS_PER_MS);
	}
}

void vLEDTask ( void * pvParameters ) {
	while (1) {
		if (global_sonar_cm > 70) {
			PORTB = 0b00000000;
		} else if (global_sonar_cm > 60) {
			PORTB = 0b00000001;
		} else if (global_sonar_cm > 50) {
			PORTB = 0b00000011;
		} else if (global_sonar_cm > 40) {
			PORTB = 0b00000111;
		} else if (global_sonar_cm > 30) {
			PORTB = 0b00001111;
		} else if (global_sonar_cm > 20) {
			PORTB = 0b00011111;
		} else if (global_sonar_cm > 10) {
			PORTB = 0b00111111;
		} else if (global_sonar_cm > 60) {
			PORTB = 0b01111111;
		} else {
			PORTB = 0b11111111;
		}
		
		vTaskDelay(10 * TICKS_PER_MS);
	}
}


int main(){
	// Task Handlers
	xTaskHandle xSonarTaskHandle, xMusicTaskHandle, xSoundTaskHandle, xLEDTaskHandle;


	/* set the I2C bit rate generator to 100 kb/s */
	TWSR &= ~0x03;
	TWBR  = 28;
	TWCR |= _BV(TWEN);

	LCD_CONTROL_DDR	 = _BV(LCD_RS_BIT) | _BV(LCD_EN_BIT) | _BV(LCD_RW_BIT);
	DDRA = 0xFF;
	
	// Set PORTD as output
	DDRD = 0xFF;
	PORTD = 0x00;
	
	// Set PORTB as LED output //
	DDRB = 0xFF;
	PORTB = 0x00;

	/*
	Create the tasks
	*/
	xTaskCreate( vSonarTask, "Sonar", 300, NULL , tskIDLE_PRIORITY, &xSonarTaskHandle );
	xTaskCreate( vLEDTask, "LED", 100, NULL, tskIDLE_PRIORITY, &xLEDTaskHandle);
	

	// Start the scheduler
	vTaskStartScheduler();
}
